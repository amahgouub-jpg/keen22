#pragma once

// SDK GENERATE BY TELEGRAM ;- (@Manish8x) (4.5.0 -- 64Bit) DM TO BUY TOOL AVLABLE FOR SELL
// Telegram:- @Manish8x
// GEN ONThu Jul 16 07:53:58 2026
 
namespace SDK
{
//---------------------By Tg @Manish8x---------------------------
//Script Structs
//---------------------By Tg @Manish8x---------------------------

// ScriptStruct AnimationBudgetAllocator.AnimationBudgetAllocatorParameters
// 0x0050
struct FAnimationBudgetAllocatorParameters
{
	float                                              BudgetInMs;                                               // 0x0000(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MinQuality;                                               // 0x0004(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxTickRate;                                              // 0x0008(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WorkUnitSmoothingSpeed;                                   // 0x000C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AlwaysTickFalloffAggression;                              // 0x0010(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InterpolationFalloffAggression;                           // 0x0014(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                InterpolationMaxRate;                                     // 0x0018(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxInterpolatedComponents;                                // 0x001C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InterpolationTickMultiplier;                              // 0x0020(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InitialEstimatedWorkUnitTimeMs;                           // 0x0024(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxTickedOffsreenComponents;                              // 0x0028(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                StateChangeThrottleInFrames;                              // 0x002C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BudgetFactorBeforeReducedWork;                            // 0x0030(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BudgetFactorBeforeReducedWorkEpsilon;                     // 0x0034(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BudgetPressureSmoothingSpeed;                             // 0x0038(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReducedWorkThrottleMinInFrames;                           // 0x003C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReducedWorkThrottleMaxInFrames;                           // 0x0040(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BudgetFactorBeforeAggressiveReducedWork;                  // 0x0044(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReducedWorkThrottleMaxPerFrame;                           // 0x0048(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BudgetPressureBeforeEmergencyReducedWork;                 // 0x004C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

